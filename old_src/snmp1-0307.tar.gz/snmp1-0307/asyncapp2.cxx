/*
 */

#include <ucd-snmp/ucd-snmp-config.h>
#include <ucd-snmp/ucd-snmp-includes.h>
#include <ucd-snmp/snmp_client.h>

// FORWARD
int print_result (int status, struct snmp_session *sp, struct snmp_pdu *pdu);

/* GPS - this is not in any header
	and it probably returns a THING * not a bool int
*/
extern "C" 
bool snmp_synch_setup(struct snmp_session * ss);

#define RECEIVED_MESSAGE SNMP_CALLBACK_OP_RECEIVED_MESSAGE

#include "named_oid.h"
#include "an_snmp_sess.h"
#include "an_snmp_async_sess.h"

#include "task_list.h"
#include "avar.h"

/*
 * a list of hosts to query
 */
struct host {
	char * name;
	char * community;
} hosts[] = {
  { "localhost",	"public" } ,
  { "127.0.0.1",	"public" } ,
  { "sky",		"public" } ,
  { "sky",		"badpass" } ,
  { "sky2",		"public" } 
/*
*/
};

named_oid named_oid_list[] = {
  named_oid( "interfaces.ifTable.ifEntry.ifOutOctets.3"	) ,
  named_oid( "system.sysDescr.0"	) ,
  named_oid( "interfaces.ifTable.ifEntry.ifDescr.2"	) ,
  named_oid( "interfaces.ifTable.ifEntry.ifOutOctets.2"	) ,
  named_oid( "interfaces.ifTable.ifEntry.ifDescr.3"	) ,
  named_oid( "interfaces.ifTable.ifEntry.ifOutOctets.3"	) 
};

void synchronous (void)
{

	int N_hosts = sizeof( hosts ) / sizeof( hosts[0] );
	int N_oids = sizeof( named_oid_list ) / sizeof( named_oid_list[0] );

	for( int h = 0; h<N_hosts; h++ ) 
	{
		struct host *hp = & hosts[h];

		an_snmp_sess s2;
		// AUTO s2.init();
		s2.set_host_pass( hp->name, hp->community );
		s2.sync_setup();
		if(! s2.sync_open() ) continue;

		for( int i = 0; i < N_oids; i++ ) {
			named_oid * OP = &named_oid_list[i];
			s2.pdu_create_GET();
			s2.add_null_var( named_oid_list[i] );
			if( s2.sync_response() ) {
				s2.print_ack();
			} else {
			}
			s2.free_ack();
		}
		s2.close();
	}
}

void asynchronous(void)
{
	// the list of oid's to send to each host
	named_oid * ENQ_LIST = named_oid_list;
	int LEN_LIST =  sizeof( named_oid_list ) / sizeof( named_oid_list[0] );
	int N_hosts = sizeof( hosts ) / sizeof( hosts[0] );

	task_list tasks;
	an_snmp_sess s2[N_hosts];

	/* prep a session per hosts */
	for( int i = 0; i< N_hosts; i++ )
	{
		job_state * job = tasks.new_task( ENQ_LIST, LEN_LIST );
 // DONE //	job->sess.init(&sess);
 // DONE //	job->sess.version = SNMP_VERSION_2c;
		job->set_host_pass( hosts[i].name, hosts[i].community );
		job->async_open();
	}

	/* start them up */
	for( int i = 0; i< N_hosts; i++ ) {
		job_state * job = tasks.task[i];
		// OK // job->send_first();
		job->send_all();
	}

  /* loop while any active hosts */

	while (tasks.N_pending > 0) {
		int fds = 0, block = 1;
		fd_set fdset;
		struct timeval timeout;

		FD_ZERO(&fdset);
		snmp_select_info(&fds, &fdset, &timeout, &block);
		fds = select(fds, &fdset, NULL, NULL, block ? NULL : &timeout);
		if (fds)
			snmp_read(&fdset);
		else
			snmp_timeout();		// possible retries
	}

  /* cleanup */

  //for (hp = hosts, hs = sessions; hp->name; hs++, hp++) {
  //  if (hs->sess) snmp_close(hs->sess);
  //}
}

/*****************************************************************************/

int main (int argc, char **argv)
{
 init_snmp( argv[0] );

if(0) {
  printf("---------- synchronous -----------\n");
  synchronous();
}

  printf("---------- asynchronous -----------\n");
  asynchronous();

  return 0;
}
/*****************************************************************************/


/*
 * simple printing of returned data
 */
int print_result (int status, struct snmp_session *sp, struct snmp_pdu *pdu)
{
  char buf[1024];
  struct variable_list *vp;
  struct timeval now;
  struct timezone tz;
  struct tm *tm;
 
	gettimeofday(&now, &tz);
	tm = localtime(&now.tv_sec);
	fprintf(stdout, "%.2d:%.2d:%.2d.%.6d ",
		tm->tm_hour,
		tm->tm_min,
		tm->tm_sec,
		now.tv_usec
	);
  switch (status) {
  case STAT_SUCCESS:
    if (pdu->errstat == SNMP_ERR_NOERROR)  {
	avar var ( pdu->variables );
	while( var ) {
		fprintf(stdout, "%s:: ", sp->peername);
		var.fprint_variable( stdout );
		var.next();
	}
	} else {
		int err_pos = pdu->errindex;
		//  int ix;
		avar var( pdu->variables );
		for (int ix = 1; ix != pdu->errindex; ix++) {
			if( !var.next() ) break;
		}
		;
		var.sprint_objid( buf );
		fprintf(stdout, "ERROR %s: %s: %s\n",
			sp->peername,
			buf,
			snmp_errstring(pdu->errstat)
		);
	}
	return 1;
	case STAT_TIMEOUT:
	fprintf(stdout, "%s: Timeout\n", sp->peername);
	return 0;
	case STAT_ERROR:
	snmp_perror(sp->peername);
	return 0;
	}
	return 0;
}
