#ifndef named_oid_H
#define named_oid_H

struct named_oid
{
	const	char * name;	/* keeps callers malloced copy */
	oid	Oid[MAX_OID_LEN]; // 128 bytes ;-)
	size_t	OidLen;

	named_oid( const char * _name )
	{
		name = _name;
		OidLen = 0;
		// require_snmp_mib();
	}
	void read_obj_id_from_mib()
	{
		if(OidLen) return; // done
		OidLen = sizeof(Oid)/sizeof(Oid[0]);
		if (!read_objid( name, &Oid[0], &OidLen)) {
			snmp_perror("read_objid_");
			snmp_perror(name);
			exit(1);
		}
	}
};
#endif
