#ifndef an_snmp_async_sess_H
#define an_snmp_async_sess_H

#include "an_snmp_sess.h"

struct an_snmp_async_sess : public an_snmp_sess
{
	int reqid;	// callback duration

	static int C_async_callback(
		int _operation,
		struct snmp_session *_sp,
		int _reqid,
		struct snmp_pdu *_pdu,
		void *magic
	)
	{
		// fprintf(stderr,"an_anmp_async_sess::C_async_callback()\n");
		an_snmp_async_sess * self = (an_snmp_async_sess *) magic;
		if( _sp != self->sp )
		{
			snmp_perror("ASYNC: sp!=ss");
		}
		self->ack = _pdu;
		self->reqid = _reqid; // 0 = trap
		switch (_operation ) {
		 case SNMP_CALLBACK_OP_RECEIVED_MESSAGE:
			self->status = STAT_SUCCESS;
			self->async_Received(); // VTBL
		 break;
		 case SNMP_CALLBACK_OP_TIMED_OUT:
		 case SNMP_CALLBACK_OP_SEND_FAILED:
			self->status = STAT_TIMEOUT;
			self->async_Timeout(); // VTBL
		 break;
		 case SNMP_CALLBACK_OP_CONNECT:
		 break;
		 case SNMP_CALLBACK_OP_DISCONNECT:
		 default:
			;
		}
		self->ack = NULL; // deleted by core
		return 1;
		/*
			1 = success
			0 = keep-pending (retransmits)
			always: pdu is deleted after return
		*/
	}

	bool sync_open()
	{
		fprintf(stderr,"an_anmp_async_sess::sync_open() - should be async_open()\n");
		return false;
	}
	bool async_open()
	{
		ss.callback = C_async_callback;
		ss.callback_magic = (void *) this;
		return an_snmp_sess::sync_open();
	}

	bool send_async()
	{
		int req_id = snmp_send(sp, enq);
		/*
			0 = error
			1 = OTHER
			X = requestid
		*/
	        if ( req_id ) {
			return true;
		}
		snmp_perror("send_async()");
		return false;
	}

	virtual void
	async_Received()
	{
		fprintf(stderr,"an_anmp_async_sess::async_Received()\n");
		// print_ack();
	}

	virtual void
	async_Timeout()
	{
		fprintf(stderr,"an_anmp_async_sess::async_Timeout()\n");
		// print_ack();
	}
};
#endif
