#ifndef a_var_H
#define a_var_H

/*
Counter32
Gauge32
Hex
IpAddress
OID
Opaque
Timeticks
*/

struct avar
{
	struct variable_list * var;

	avar( struct variable_list * _var ) {
		var = _var;
	}

	void set( struct variable_list * _var ) {
		var = _var;
	}

	bool next() 
	{
		if(!var) return false;
		var = var->next_variable;
		return bool(var);
	}

	operator bool()
	{
		return var;
	}

	void fprint_variable(FILE * f)
	{
		::fprint_variable(f, var->name, var->name_length, var);
	}

	void sprint_objid(char * buff )
	{
		if( var )
			::sprint_objid( buff, var->name, var->name_length );
		else
			strcpy( buff, "(NONE)" );
	}

	long get_long()
	{
		switch( var->type ) {
		 case ASN_INTEGER:
		 case ASN_COUNTER:
		 case ASN_GAUGE:
		 case ASN_TIMETICKS:

		/* defined types (from the SMI, RFC 1157) */
		 case ASN_IPADDRESS:
	//	 case ASN_COUNTER:
	//	 case ASN_GAUGE:
	//	 case ASN_UNSIGNED:
		 case ASN_UINTEGER:	/* historic - don't use */
	//	 case ASN_TIMETICKS:
		 case ASN_OPAQUE:
		/* defined types (from the SMI, RFC 1442) */
		 case ASN_NSAP:		 /* historic - don't use */
		 case ASN_COUNTER64:
		#ifdef OPAQUE_SPECIAL_TYPES
		/* defined types from draft-perkins-opaque-01.txt */
		 case ASN_FLOAT:
	//	 case ASN_DOUBLE:
		 case ASN_INTEGER64:
		 case ASN_UNSIGNED64:
		#endif /* OPAQUE_SPECIAL_TYPES */
		 default:
		 ;
		}
	}
};

#endif
