#ifndef an_snmp_sess_H
#define an_snmp_sess_H

struct an_snmp_sess
{
	struct snmp_session ss;
	struct snmp_session * sp;
	struct snmp_pdu * enq;
			
	struct snmp_pdu * ack;
	int status;
	an_snmp_sess()
	{
		snmp_sess_init(&ss);		/* initialize session */
		ss.version = SNMP_VERSION_2c;
		enq = NULL;
		ack = NULL;
		sp = NULL;
	}
	~an_snmp_sess()
	{
		close();
		free_ack();
		// CRASH // free_enq();
		free_enq();
	}
	int set_host_pass( char * host, char * pass ) // retain malloc
	{
		close(); // ? 
		ss.peername = host;
		ss.community = (u_char *)pass;
		ss.community_len = strlen(pass);
	}
	void print_ack_2()
	{
		struct variable_list * vp;
		char attr_name [1200];
		char attr_val[1200];
		vp = ack->variables;
		while(vp) {
			sprint_variable( attr_name, vp->name, vp->name_length, vp );
			fprintf(stdout, "%10s %s\n",
				sp->peername,
				attr_name
			);
			vp = vp->next_variable;
		}
	}
	int print_ack()
	{
		return print_result( status, &ss, ack );
	}
	int sync_setup()
	{
		return snmp_synch_setup(&ss);
	}
	bool sync_open()
	{
		// should maybe have a different subtype for an OPEN sess
		close();
		// struct snmp_session * sp;
		if (!(sp = snmp_open(&ss))) {
			snmp_perror("snmp_open");
			return false;
		}
		return true;
	}

	bool pdu_create_GET()
	{
		// is this ever free'd??
		enq = snmp_pdu_create(SNMP_MSG_GET);
		if( !enq ) {
			snmp_perror("pdu_create(GET)");
		}
		return true;
	}
	void add_null_var( named_oid & OP )
	{
		OP.read_obj_id_from_mib();
		snmp_add_null_var( enq, OP.Oid, OP.OidLen);
	}
	int sync_response()
	{
		// struct snmp_session * sp = &ss; // ??
		if( ack ) free_ack();
		status = snmp_synch_response( sp, enq, &ack);
		free_enq_done(); // MAYBE NOT ALWAYS - want to print failed enq?
		return status;
	}
	int send_and_wait_for_response()
	{
		return sync_response();
	}
	void free_enq()
	{
		if(enq) snmp_free_pdu(enq);
		enq = NULL;
	}
	void free_enq_done()	// lib snmp has freed the enq (sent it)
	{
		enq = NULL;
	}
	void free_ack()
	{
		if(ack) snmp_free_pdu(ack);
		ack = NULL;
	}
	void close()
	{
		// struct snmp_session * sp = &ss; // ??
		if( sp ) snmp_close(sp);
		sp = NULL;
		free_enq();	
		free_ack(); // DONT - keep the last result?
	}
};

#endif
