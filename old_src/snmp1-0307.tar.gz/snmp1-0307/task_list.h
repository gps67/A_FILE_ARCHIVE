
struct job_state : public an_snmp_async_sess
{
	named_oid * list;
	int list_len;
	int list_pos;
	int * counter; // or some other semaphore

	job_state( named_oid * _list, int _list_len, int * _counter )
	{
		list = _list;
		list_len = _list_len;
		list_pos = -1;
		counter = _counter;
	}

	bool send_next() // returns one started or nonew pending
	{
		list_pos ++;	// starting from -1, now [0[N
		if( list_pos  == list_len ) {
			list_pos ++; // two past - flag
			sending_done(); // first ==
		}
		if( list_pos >= list_len ) {
			return false;
		}
		named_oid * attr = & list[list_pos];
		pdu_create_GET();
		add_null_var( *attr );
		if( !send_async() ) {
			// not quite right - stop on error ?
			sending_done();
			return false;
		}
		pending_more();
		return true;
	}

	bool send_first()
	{
		return send_next();
	}	

	void send_all()
	{
		while( send_next()) { }
	}

	virtual void
	async_Received()
	{
		// fprintf(stderr,"job::async_Received()\n");
		fprintf(stderr,"%3d ", *counter);
		print_ack();
		// print_ack_2();
		pending_less();
		send_next();
	}

	virtual void
	async_Timeout()
	{
		fprintf(stderr,"--- job::async_Timeout()\n");
		print_ack();
		pending_less();
	}

	void pending_more()
	{
		fflush(0);
 if(0)		fprintf(stderr,"%3d job::pending_more()\n", *counter);
		fflush(0);
		(* counter) ++;
	}

	void pending_less()
	{
		fflush(0);
 if(0)		fprintf(stderr,"%3d job::pending_less()\n", *counter);
		fflush(0);
		(* counter) --;
	}
	// this is NOT called by pending counter
	// but is called when no further requests exist or have been sent
	// not quite right, but thisis not a semaphore demo
	void sending_done()
	{
		fflush(0);
		fprintf(stderr,"--- job::DONE()\n");
		fflush(0);
	}

};

struct task_list
{
	job_state * task[20];	// this is dummy caller stuff
	int N_task;
	int N_pending;

	task_list()
	{
		N_task = 0;
		N_pending = 0;
	}
	void add_task( job_state * job )
	{
		task[ N_task++ ] = job;
	}
	job_state * new_task( named_oid * _list, int _list_len )
	{
		job_state * job = new job_state( _list, _list_len, & N_pending );
		add_task( job );
		return job;
	}
	void del_task( job_state * job )
	{
		for( int i = 0; i < N_task; i++ )
		{
			if( task[i] == job )
			{
				delete job;
				task[i] = NULL;
			}
		}
	}
};

